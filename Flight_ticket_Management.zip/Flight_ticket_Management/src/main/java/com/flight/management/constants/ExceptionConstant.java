
package com.flight.management.constants;


public interface ExceptionConstant {

    public static final String INVALID_FORMAT_EC = "101";
    public static final String INVALID_FORMAT_ED = "File Format Invalid !";

    public static final String EMPTY_FILE_EC = "102";
    public static final String EMPTY_FILE_ED = "Empty file uploaded";

    public static final String SIZE_EXCEEDED_EC = "103";
    public static final String SIZE_EXCEEDED_ED = "File size exceeded the limit";

    public static final String INVALID_HEADER_EC = "104";
    public static final String INVALID_HEADER_ED = "File Header is Invalid";

    public static final String UNKNOWN_ERROR_EC = "100";
    public static final String UNKNOWN_ERROR_ED = "Unknown Exception ";

    public static final String JOB_NOT_FOUND_EC = "105";
    public static final String JOB_NOT_FOUND_ED = "Job name Invalid ";

    public static final String INVALID_MSISDN_CUST_CODE_EC = "106";
    public static final String INVALID_MSISDN_CUST_CODE_ED = "Invalid MSISDN /CUST CODE";

    public static final String FILE_NOT_EXIST_EC = "106";
    public static final String FILE_NOT_EXIST_ED = "File does't Exist";

    public static final String DATA_NOT_FOUND_ED = "Expected data not found";
    public static final String DATA_NOT_FOUND_EC = "108";
    
    public static final String  NULL_VALUES_ED  = "Null Values Not Allowed ";
    public static final String  NULL_VALUES_EC= "109";


}
