package com.flight.management.dto;

import org.springframework.stereotype.Component;

@Component
public class BookFlightRequest {

	private String flightNumber;
	private String noOfSeats;
	
	
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(String noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	
	
}
