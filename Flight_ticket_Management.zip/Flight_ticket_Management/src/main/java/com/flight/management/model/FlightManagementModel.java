package com.flight.management.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "flight_management")
public class FlightManagementModel {
	

	@Column(name="ID")
	@Id
	private int id;
	
	@Column(name="FLIGHT_NAME")
	private String flightName;
	
	
	@Column(name="PASSENGER_NAME")
	private String passengerName;

	@Column(name="STATUS")
	private String status;
	
	@Column(name="SEAT_NO")
	private String seatNo;

	
	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getSeatNo() {
		return seatNo;
	}


	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}


	public String getFlightName() {
		return flightName;
	}


	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}


	public String getPassengerName() {
		return passengerName;
	}


	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	
}
