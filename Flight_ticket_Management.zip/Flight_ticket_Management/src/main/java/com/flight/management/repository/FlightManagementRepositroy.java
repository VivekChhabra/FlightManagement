package com.flight.management.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.flight.management.model.FlightManagementModel;

import antlr.collections.List;

@Repository
@Transactional
public interface FlightManagementRepositroy extends JpaRepository<FlightManagementModel, Integer> {

	@Query(value="select count(*) from FlightManagementModel fm where fm.status='AVAILABLE' and fm.flightName=:flightNo")
	long getAllAvailableSeats(@Param("flightNo")String flightNo);

	java.util.List<FlightManagementModel> findByflightName(String flightNumber);
	
	

}
