
package com.flight.management.constants;

public class ConstantURL {

	public static final String Rest_Controller = "/flightManagement";
	public static final String Search_TICKETS_URL = "/getFlightDetails";
	public static final String CANCEL_TICKET_URL = "/cancelticket";
	public static final String NEW_FLIGHT_URL = "/newFlight";
	public static final String BOOK_TICKET_URL = "/bookTicket";
	
}
