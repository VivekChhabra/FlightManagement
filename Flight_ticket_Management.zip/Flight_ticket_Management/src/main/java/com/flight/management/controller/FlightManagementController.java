package com.flight.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.flight.management.constants.ConstantURL;
import com.flight.management.dto.BookFlightRepsonse;
import com.flight.management.dto.BookFlightRequest;
import com.flight.management.dto.BookNewFlightRepsonse;
import com.flight.management.dto.BookTicketRequest;
import com.flight.management.dto.FlightDetailsResponse;
import com.flight.management.dto.SearchFlightTicketsDTO;
import com.flight.management.service.FlightManagementService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = ConstantURL.Rest_Controller)
@Api(value = "Flight Management Rest Controller")
public class FlightManagementController {

	@Autowired
	FlightManagementService flightManagementService;




	@ApiOperation(value = "Search Flight Seats ", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = ""), @ApiResponse(code = 201, message = "") })
	@RequestMapping(value = ConstantURL.Search_TICKETS_URL, method = RequestMethod.POST, produces = "application/json")
	@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*") // @PostMapping(value =
																					// ConstantURL.Bank_Search_URL)
	public FlightDetailsResponse searchBankStatement(@RequestBody final SearchFlightTicketsDTO searchFields) throws Exception {

		return flightManagementService.searchFlightTickets(searchFields);
	}

	@ApiOperation(value = "Book Flight Ticket", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = ""), @ApiResponse(code = 201, message = "") })
	@RequestMapping(value = ConstantURL.BOOK_TICKET_URL, method = RequestMethod.POST, produces = "application/json")
	@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
	public BookFlightRepsonse bookTicket(@RequestBody BookTicketRequest remarksDto) {
		return flightManagementService.bookTicket(remarksDto);
	}
	

	@ApiOperation(value = "Book Flight", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = ""), @ApiResponse(code = 201, message = "") })
	@RequestMapping(value = ConstantURL.NEW_FLIGHT_URL, method = RequestMethod.POST, produces = "application/json")
	@CrossOrigin(origins = "*", allowCredentials = "true", allowedHeaders = "*")
	public BookNewFlightRepsonse bookFlight(@RequestBody BookFlightRequest remarksDto) {
		return flightManagementService.bookFlight(remarksDto);
	}
	

}