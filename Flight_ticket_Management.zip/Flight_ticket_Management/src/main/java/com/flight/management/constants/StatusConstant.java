package com.flight.management.constants;


public interface StatusConstant {

	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAILURE = "FAILURE";
	public static final String BOOKED = "BOOKED";
}
