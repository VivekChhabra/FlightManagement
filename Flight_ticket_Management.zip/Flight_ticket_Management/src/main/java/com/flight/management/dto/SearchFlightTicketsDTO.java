package com.flight.management.dto;

import org.springframework.stereotype.Component;

@Component
public class SearchFlightTicketsDTO {

	private String flightNo;

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	
	
	
	
	
}
