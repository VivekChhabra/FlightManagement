package com.flight.management.dto;

import java.util.List;

import org.springframework.stereotype.Component;


@Component
public class FlightDetailsResponse  {
	 private String status;
	
	 private String seats;
	    
	

	public String getSeats() {
		return seats;
	}

	public void setSeats(String seats) {
		this.seats = seats;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

		
}
