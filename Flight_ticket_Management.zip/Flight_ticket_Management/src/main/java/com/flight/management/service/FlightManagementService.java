package com.flight.management.service;

import org.springframework.stereotype.Service;

import com.flight.management.dto.BookFlightRepsonse;
import com.flight.management.dto.BookFlightRequest;
import com.flight.management.dto.BookNewFlightRepsonse;
import com.flight.management.dto.BookTicketRequest;
import com.flight.management.dto.FlightDetailsResponse;
import com.flight.management.dto.SearchFlightTicketsDTO;


@Service
public interface FlightManagementService {


	FlightDetailsResponse searchFlightTickets(SearchFlightTicketsDTO searchFields);

	BookFlightRepsonse bookTicket(BookTicketRequest remarksDto);

	BookNewFlightRepsonse bookFlight(BookFlightRequest remarksDto);


}
