package com.flight.management.serviceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.management.constants.StatusConstant;
import com.flight.management.dto.BookFlightRepsonse;
import com.flight.management.dto.BookFlightRequest;
import com.flight.management.dto.BookNewFlightRepsonse;
import com.flight.management.dto.BookTicketRequest;
import com.flight.management.dto.FlightDetailsResponse;
import com.flight.management.dto.SearchFlightTicketsDTO;
import com.flight.management.model.FlightManagementModel;
import com.flight.management.repository.FlightManagementRepositroy;
import com.flight.management.service.FlightManagementService;

@Service
public class flightManagementServiceImpl implements FlightManagementService {

	@Autowired
	FlightManagementRepositroy flightManagementRepository;

	
	private static final Logger LOGGER = LoggerFactory.getLogger(flightManagementServiceImpl.class);




	@Override
	public FlightDetailsResponse searchFlightTickets(SearchFlightTicketsDTO searchFields) {
		
		FlightDetailsResponse response = new FlightDetailsResponse();
		try {
		long count = flightManagementRepository.getAllAvailableSeats(searchFields.getFlightNo());
		response.setSeats(count+"");
		response.setStatus(StatusConstant.STATUS_SUCCESS);
		LOGGER.info("SUCCESS");
		}
		catch(Throwable th) {
			LOGGER.error(th.getLocalizedMessage());
			response.setStatus(StatusConstant.STATUS_FAILURE);
		}
		return response;
	}




	@Override
	public BookFlightRepsonse bookTicket(BookTicketRequest bookRequest) {
		BookFlightRepsonse response = new BookFlightRepsonse();
		try {
			
				FlightManagementModel flightManagement = new FlightManagementModel();
				flightManagement.setFlightName(bookRequest.getFlightNo());
				flightManagement.setPassengerName(bookRequest.getPassengerName());
				flightManagement.setSeatNo((int) Math.random()+"");
				
				flightManagement.setStatus(StatusConstant.BOOKED);
				 
				flightManagementRepository.save(flightManagement);
			  
			  LOGGER.info("SUCCESS");
			  response.setStatus(StatusConstant.STATUS_SUCCESS);
			  
			  response.setSeatNo(flightManagementRepository.findById(flightManagement.getId()).get().getSeatNo());
		}
		catch(Throwable th){
			LOGGER.error(th.getLocalizedMessage());
			response.setStatus(StatusConstant.STATUS_FAILURE);
		}
		
		return response;
	}




	@Override
	public BookNewFlightRepsonse bookFlight(BookFlightRequest request) {
			BookNewFlightRepsonse response = new BookNewFlightRepsonse();
			try {
				List<FlightManagementModel> obj = flightManagementRepository.findByflightName(request.getFlightNumber());
				if(obj != null ) {
					FlightManagementModel newFlight = new FlightManagementModel();
					
					newFlight.setFlightName(request.getFlightNumber());
					flightManagementRepository.save(newFlight);
					response.setMessage(StatusConstant.STATUS_SUCCESS);
				}
				else {
					response.setMessage("Flight already exists");
					response.setStatus(StatusConstant.STATUS_FAILURE);
				}
			}
			catch(Throwable th) {
				LOGGER.error(th.getLocalizedMessage());
				response.setStatus(StatusConstant.STATUS_FAILURE);
			}
					
		return response;
	}

	

}
