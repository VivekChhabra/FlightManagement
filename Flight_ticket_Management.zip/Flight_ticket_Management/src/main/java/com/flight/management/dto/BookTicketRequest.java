package com.flight.management.dto;

public class BookTicketRequest {

	private String passengerName;
	
	private String flightNo;
	
	
	
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	
	
	
	
	
}
