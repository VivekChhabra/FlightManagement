package com.flight.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightTicketManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightTicketManagementApplication.class, args);
	}

}
